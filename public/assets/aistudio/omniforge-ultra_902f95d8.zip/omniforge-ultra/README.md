# OmniForge Ultra — Universal AI Execution Skill

**Version:** 1.0.0  
**Format:** Open Agent Skills folder (`SKILL.md` + optional supporting files)  
**License:** MIT for the authored skill text and templates. Third-party tools, engines, assets, and models retain their own licenses.

## What it does

OmniForge Ultra is a reusable operating playbook for AI agents that must deliver substantial work rather than stop at a concept, mockup, or untested code sample. It gives the agent an end-to-end loop for planning, building, testing, inspecting, repairing, securing, and delivering work across software, games, apps, 3D, research, mathematics, data, and computer use.

The package includes:

- `SKILL.md` — required entrypoint and universal instructions.
- `references/` — deeper production, QA, security, research, and benchmark guidance.
- `templates/` — task contract, bug log, release checklist, and verification report.
- `scripts/validate_skill.py` — dependency-free package structure and link checker.
- `assets/benchmark-reference.png` — the comparison image supplied with the request.

## Install / use

1. Keep the `omniforge-ultra` folder intact, or use `omniforge-ultra.zip` as the distribution bundle.
2. In an agent product that supports the open Agent Skills format, upload/import the ZIP or place the folder in that product's configured skills directory.
3. Ask the agent to **use the `omniforge-ultra` skill** for the task.
4. If an AI product does not support skill folders, attach the folder (or at minimum `SKILL.md` and the relevant references) and instruct it to read and follow the skill. Compatibility depends on that product's file/tool support.

## Important capability boundary

A skill is reusable instruction and reference material. It can improve task discipline and quality assurance, but it cannot upgrade the underlying model, make one model objectively smarter than another, guarantee higher benchmark scores, create missing tools, grant unrestricted PC/app access, or override system/developer instructions and platform safeguards. For real computer use, the AI must have supported tools and the user must grant appropriate permissions.

## Suggested activation prompt

> Use the `omniforge-ultra` skill. Complete the requested task end to end. Inspect the existing workspace first, preserve existing work, implement the real deliverable in verified slices, test every critical path, inspect the actual visual/runtime result, repair defects, and provide the files plus an evidence-based verification report. Make sensible reversible assumptions instead of stopping for nonessential questions. Respect security, permissions, and platform rules.

## Validate the package

Run:

```bash
python scripts/validate_skill.py
```

The validator checks the required skill entrypoint, frontmatter basics, referenced local files, and expected support folders. It does not certify the AI's reasoning, code, security, or the quality of a project built with the skill.

## Benchmark image

The supplied image is preserved at `assets/benchmark-reference.png`, and its visible figures/notes are transcribed in `references/benchmark-inspired-scorecard.md`. Treat those numbers as source-image data—not as independently audited results or a promise of what any model will achieve.
