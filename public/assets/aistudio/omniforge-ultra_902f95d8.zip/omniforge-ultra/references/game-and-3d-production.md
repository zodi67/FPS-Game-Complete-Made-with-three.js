# Game, Interactive 3D, and AAA Production Standard

Use this reference for full games, game prototypes that must be expanded, interactive simulations, 3D environments, characters, props, animation packs, and real-time experiences.

## 1. Turn the brief into a complete game specification

Define:

- Player fantasy, genre, target audience, platform, camera perspective, session length, and input devices.
- Core loop: player action → world response → reward/consequence → next objective.
- Win/lose/fail/retry conditions, progression, difficulty curve, and onboarding.
- World boundaries, interaction rules, NPC/enemy behavior, physics rules, and game-state transitions.
- Menus, HUD, settings, pause, save/load, restart, accessibility, audio, and localization needs.
- Performance targets for named device classes, not a vague “all devices” promise.
- Multiplayer scope: authority model, matchmaking/lobbies, replication, latency handling, cheating risks, reconnect, and server costs where relevant.

Create a feature matrix and acceptance checklist. Do not treat a visually impressive opening scene as a complete game.

## 2. Build a real playable vertical slice

The first integrated slice should prove the main experience using real systems:

- Launch into the actual game scene.
- Player movement and camera controls work on the intended devices.
- At least one complete interaction demonstrates the core loop.
- World feedback, animation, audio, and UI respond to the interaction.
- Success/failure and restart paths work.
- The feature can be tested repeatedly without resetting the entire project manually.

Then expand feature-by-feature. Keep the vertical slice; do not throw it away and rebuild a disconnected mockup.

## 3. Character and creature quality

For each character/creature:

- Check silhouette and proportions from gameplay distance and common viewing angles.
- Confirm scale against doors, props, vehicles, terrain, and other characters.
- Inspect topology density and edge flow around joints, face, deformation zones, and silhouette.
- Check normals, smoothing, seams, UV layout, texel density, texture resolution, material response, and shader compatibility.
- Check eyes, mouth, teeth, tongue, horns, hands/feet, fingers/claws, and contact points where applicable.
- Avoid intersections, floating details, mesh gaps, stretched textures, pinching, and accidental self-collision.
- Use LODs or simplified variants when target hardware requires them.

A model is not “realistic” merely because it has many polygons or a high-resolution texture. Judge the complete asset in the target engine and lighting.

## 4. Rigging and animation

For every animated character or object:

- Verify bone hierarchy, naming, orientation, bind pose, scale, and parent-child relationships.
- Inspect skin weights and deformation at elbows, knees, shoulders, hips, wrists, neck, jaw, fingers, tail, and other high-motion areas.
- Test IK/FK behavior, constraints, retargeting, root motion, and animation layers where used.
- Validate idle, locomotion, start/stop, turns, jumps, falls, attacks, reactions, interaction, hit recovery, and death/disable states as applicable.
- Check foot sliding, ground penetration, hand/object contact, body intersections, snapping, popping, loop seams, and timing.
- Ensure animation state changes are driven by real game state and blend smoothly under rapid input changes.
- Inspect at normal gameplay speed, slow motion, and from the actual player camera.

Every animation shown in the UI or design brief should be connected to an actual state or clearly marked as an unused asset. Do not count an animation file as a working animation system.

## 5. Collision and physics verification

Treat visual meshes and physics colliders as different systems. Verify:

- Correct collision layers, masks, groups, and trigger/query settings.
- Collider size, orientation, offsets, compound collider layout, and center of mass.
- Ground contact, slopes, stairs, ledges, doors, narrow spaces, ceilings, moving platforms, and corners.
- Player-to-world, object-to-object, projectile, vehicle, ragdoll, and NPC interactions as relevant.
- Friction, restitution, mass ratios, damping, joints, constraints, and stable resting positions.
- Fast movement and tunneling; use continuous collision detection or substeps when appropriate.
- Trigger entry/exit, duplicate events, collision filtering, and multiplayer authority if relevant.
- No unintended clipping through floors/walls, no hovering due to collider offsets, and no jitter from overlapping bodies.

Test physical interaction in the engine with representative speeds and edge cases. A collider that exists in the editor is not proof that gameplay collision works.

## 6. Environment and level production

Inspect:

- Scale, navigation routes, sightlines, landmarks, readability, cover, traversal, and safe spawn points.
- Terrain seams, floating objects, z-fighting, intersecting meshes, light leaks, shadow artifacts, and missing collision.
- Modular snapping, pivot/origin placement, grid consistency, texture/material reuse, and level streaming boundaries.
- Occlusion, culling, LOD transitions, shadow distance, fog, lighting, and reflection quality.
- NPC navigation, blocked paths, dynamic obstacles, stuck recovery, and fall/reset behavior.
- Interactive objects have a clear state, feedback, and collision/trigger behavior.

Walk/fly the level using a debug camera and play it using the intended camera. Check the route players will actually take, not only the editor overview.

## 7. UI, controls, and player feedback

For every interactive control, verify:

- Mouse, keyboard, controller, touch, or accessibility input as required.
- Input mapping, dead zones, sensitivity, simultaneous inputs, and input interruption.
- Visual/audio feedback and state changes on press, hold, release, disabled, loading, and failure.
- Focus navigation, safe-area layout, resolution scaling, text readability, and localization overflow.
- Pause, settings, remapping, audio sliders, restart, exit, and confirmation flows.
- HUD values match the actual game state; no stale or fake counters.

A button is not functional because it changes color. Test what it is supposed to do and verify the resulting state.

## 8. AI, enemies, and NPCs

Where used, define state machines or behavior trees with explicit transitions. Test perception range, line of sight, target selection, pathfinding, patrol, chase, attack, retreat, cooldowns, hit reactions, stuck detection, and reset/death. Prevent impossible targeting, wall attacks, rapid state oscillation, animation/state mismatch, and excessive CPU usage. Test multiple agents concurrently where performance or coordination matters.

## 9. Audio and effects

Check event triggers, spatialization, volume hierarchy, priority/voice limits, attenuation, occlusion, looping, synchronization, mixing, mute/settings behavior, and platform-specific playback. Effects must not obscure essential information or create excessive overdraw. Ensure impact and interaction feedback match the actual event timing.

## 10. Multiplayer and networking

If multiplayer is in scope, explicitly test:

- Server/client authority and ownership of movement, physics, inventory, combat, and rewards.
- Replication, interpolation, prediction, reconciliation, late join, reconnect, host migration if supported, and disconnect cleanup.
- Lag, jitter, packet loss, duplicate messages, out-of-order events, and timeouts.
- Server-side validation of important actions; never trust client claims for valuable state.
- Matchmaking/lobby lifecycle, ready state, team assignment, spawn synchronization, and session shutdown.
- Cheating surfaces, rate limiting, input validation, and abuse reporting as appropriate.

Do not present local split-screen, bots, or a simulated network as online multiplayer.

## 11. Performance and device validation

Measure on real target hardware when possible. Track frame time, CPU/GPU time, draw calls, triangles, shader complexity, texture memory, allocations, garbage collection, load times, network traffic, battery, and thermals where available. Use quality tiers, resolution scaling, LODs, culling, batching, instancing, pooling, streaming, and shader simplification based on profiling evidence. Report the devices and settings actually tested.

## 12. Final game QA pass

Run a complete playthrough from fresh launch. Exercise the main loop, edge cases, pause/resume, settings, saving/loading, failure, restart, exit, and any multiplayer flow. Capture screenshots/video or logs when available. Inspect all major assets at runtime. Create a list of defects, fix by severity, rerun regression tests, and provide the final build plus a verification report and known limitations.
