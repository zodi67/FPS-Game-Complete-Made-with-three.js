# Research, Mathematics, and Data Quality Protocol

Use for technical research, science, quantitative analysis, forecasts, calculations, experiments, spreadsheets, and decision support.

## 1. Frame the question

- Restate the exact question and decision the result should support.
- Define scope, geography, time period, units, population, and inclusion/exclusion criteria.
- Separate what is known from what must be researched or calculated.
- Identify the precision required. Do not imply more precision than the inputs support.

## 2. Evidence and source handling

- Prefer primary sources: original papers, official documentation, standards, government data, direct datasets, and first-party disclosures.
- Use recent sources for changing facts, and verify event date separately from publication date.
- Cross-check material claims using independent sources when practical.
- Record the source, date accessed/publication date, method, and limitations.
- Distinguish source statements, model synthesis, assumptions, and estimates.
- Do not fabricate citations, quotations, sample sizes, benchmark results, or missing values.
- If the provided material is the required basis, do not silently replace it with outside information. Clearly label any additional research.

## 3. Mathematics and numerical work

- Write down the formula or reasoning path for nontrivial calculations.
- Preserve units and convert explicitly. Check dimensional consistency.
- Verify results independently using a second method, implementation, or sanity check when practical.
- Test boundary values, signs, rounding, overflow/underflow, missing values, and order-of-magnitude plausibility.
- Avoid premature rounding. State assumptions and meaningful precision.
- For probability or statistics, identify sample size, distribution/assumptions, uncertainty, and relevant confounders.
- For optimization, state objective, constraints, variables, and whether the solution is exact, approximate, or heuristic.

## 4. Data analysis

- Inspect schema, types, units, missingness, duplicates, outliers, date ranges, and sampling process before analysis.
- Preserve the raw input. Use a reproducible transformation pipeline.
- Validate joins, groupings, filters, aggregations, and denominators.
- Watch for leakage, selection bias, survivorship bias, confounding, and nonrepresentative samples.
- Label missing or suppressed values accurately; do not quietly convert them to zero.
- Use charts with truthful axes, units, baselines, and readable labels.
- Reconcile important totals and compare results against independent summaries when available.

## 5. Experiment and reproducibility

- Define hypothesis, variables, controls, metrics, and stopping criteria.
- Record software versions, seeds, data snapshots, configuration, and steps where feasible.
- Separate exploratory observations from confirmatory results.
- Re-run critical calculations or experiments from clean inputs.
- Report negative, null, or inconclusive findings honestly; do not cherry-pick.

## 6. Final answer quality

Provide the conclusion first, then method/evidence, assumptions, uncertainties, and what would change the conclusion. Cite material claims. Use tables or plots only when they improve understanding. Never overstate causation from correlation or generalize beyond the data.
