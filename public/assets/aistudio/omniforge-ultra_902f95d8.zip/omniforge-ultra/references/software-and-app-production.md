# Software and App Production Standard

Use this reference for websites, mobile/desktop apps, APIs, tools, automation software, services, and production code changes.

## 1. Requirements and architecture

- Convert the brief into user stories or use cases with observable acceptance criteria.
- Identify target OS, browsers, devices, runtime, language/framework, deployment environment, accessibility needs, data sensitivity, and expected scale.
- Inspect the existing repository before selecting an architecture. Preserve conventions unless there is a concrete reason to change them.
- Define module boundaries, data ownership, API contracts, persistence, permissions, error handling, observability, and rollback strategy.
- Prefer the simplest maintainable architecture that fully meets the scope. Avoid speculative services, needless abstractions, and unrequested dependencies.
- Record important decisions and assumptions. Do not quietly turn an ambiguous requirement into a hidden product decision.

## 2. Complete feature implementation

For each feature, consider the full lifecycle:

1. Entry point and discoverability.
2. Valid inputs, defaults, validation, and boundary values.
3. Main success flow.
4. Loading/progress state.
5. Empty state.
6. Error state with a useful recovery path.
7. Cancellation, retry, and back navigation where relevant.
8. Persistence and restoration after restart where expected.
9. Permissions and authorization.
10. Accessibility and responsive behavior.
11. Analytics/logging only when appropriate and privacy-respecting.
12. Tests for normal and failure paths.

Every visible control must do what its label implies. A button that only animates on click but performs no action is not implemented. A save action must actually persist the expected data. A login screen must connect to real authentication or clearly identify a deliberately local/demo mode; never imply real authentication when it is mocked.

## 3. Code quality

- Follow the project's formatting, lint, naming, type, and error-handling conventions.
- Keep functions and modules focused. Prefer explicit types and schemas at system boundaries.
- Handle null/missing data, timeouts, retries, rate limits, concurrency, and partial failures deliberately.
- Do not swallow exceptions or return fake success values.
- Avoid hard-coded secrets, machine-specific paths, unexplained magic values, and dead code.
- Pin or constrain dependencies appropriately; document why new dependencies are needed.
- Add comments for non-obvious decisions, not to narrate obvious code.
- Keep compatibility with the existing supported runtime unless a version upgrade is requested and tested.

## 4. Testing pyramid

Choose a meaningful mix, not a ritual checklist:

- Unit tests for deterministic logic, transformations, calculations, validation, and edge cases.
- Integration tests for databases, file storage, queues, services, APIs, and component boundaries.
- End-to-end tests for the most important user journeys.
- Contract tests for public APIs and external service interfaces where useful.
- Regression tests for every repaired bug that can be represented reliably.
- Accessibility checks for keyboard navigation, labels, focus, contrast, and screen-reader semantics where relevant.
- Device/browser checks across the explicitly supported matrix.

Report what actually ran, command used, environment, result, and skipped tests. Never claim comprehensive test coverage just because a test command exited successfully; inspect its summary and ensure it covered the changed code.

## 5. UI/UX review

Inspect the running interface at representative viewport sizes. Review:

- Visual hierarchy, consistency, spacing, typography, icon alignment, and content clarity.
- Responsive breakpoints, overflow, clipping, overlapping elements, and touch-target size.
- Focus order, keyboard access, visible focus, contrast, reduced-motion behavior, and semantic labels.
- Loading, empty, validation, error, success, and disabled states.
- Forms, date/time, localization, long text, unusual characters, and slow-network behavior.
- Navigation loops, dead ends, modal dismissal, browser history, and state restoration.

Do not rely solely on source code or a single desktop screenshot. Interact with the app when possible.

## 6. Data, APIs, and persistence

- Validate all untrusted input on the server or trusted boundary; client-side validation is not sufficient.
- Enforce authorization at each protected operation, not only by hiding controls.
- Use transactions and consistency rules where multiple writes must succeed together.
- Handle duplicate requests and retries safely (idempotency where appropriate).
- Avoid logging credentials, personal data, tokens, or sensitive payloads.
- Test missing records, duplicate records, stale data, malformed input, network loss, and partial failures.
- Verify actual persistence by reading the data back through the intended path.
- Plan schema migration and rollback when data structures change.

## 7. Security review

Use the secure-operation reference. At minimum check:

- Authentication and authorization boundaries.
- Input validation, output encoding, injection, path traversal, unsafe deserialization, and file upload handling.
- Cross-site scripting, CSRF, SSRF, CORS, and security headers where applicable.
- Secret and token storage, rotation, exposure in logs, and repository history.
- Dependency provenance and known vulnerabilities.
- Rate limits, abuse controls, session expiry, and account recovery.
- Least-privilege permissions and safe defaults.

Do not claim “secure” from a checklist alone. State the checks performed and the threat model's limits.

## 8. Build, release, and handoff

- Run the official build/package pipeline for the target platform.
- Test installation, startup, update/migration, and uninstall/cleanup paths where applicable.
- Verify signing, permissions, environment variables, assets, and included files.
- Produce a concise README with prerequisites, setup, configuration, run, test, build, and troubleshooting commands.
- Separate development configuration from production secrets and settings.
- Include a release checklist and known issues. Do not publish or distribute externally without the required authorization.
