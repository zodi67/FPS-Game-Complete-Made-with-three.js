# Benchmark-Inspired Capability and QA Scorecard

This reference transcribes the comparison image supplied by the user. The image is also preserved as `../assets/benchmark-reference.png`. The table is a design input for what the skill should cover; it is not an independent audit, universal ranking, or promise that an agent following these instructions will reproduce any score.

## Values visible in the supplied comparison image

| Work area | Benchmark | Fable 5.2 | Fable 5.1 | Opus 5.5 | GPT-6 Astra | Gemini 4 Carbon |
|---|---|---:|---:|---:|---:|---:|
| Agentic coding | FrontierCode 2.0 | 49.1% | 32.4% | 45.5% | 42.8% | 41.1% |
| Agentic coding | FrontierSWE v2 | 69.9% | 56.3% | 62.3% | 65.5% | 61.2% |
| Business workflows | AutomationBench | 51.4% | 31.4% | 42.5% | 41.4% | 53.9% |
| Agentic scientific research | Terminal-Bench-Science 0.1 | 74.6% | 52.6% | 58.7% | 68.1% | 64.8% |
| Cybersecurity | CyScenarioBench | 76.3%* | 61.7%* | 67.6%† | 61%‡ | — |
| Cybersecurity | CVE Rediscovery | 89.6%* | 78.3%* | 81.3%† | — | — |
| Protein design | De novo binder design (24 hr) | 85.1%* | 79.1%* | 82.6%† | — | — |
| Agentic search | WANDR (relaxed score) | 82.1% | 68.7% | 72.3% | — | — |
| Computer use | OSWorld 2.1 (offline set, partial) | 89.3% | 83.5% | 87.2% | 79.5% | 81.5% |
| Robotics | RoboDojo Sim | 64.9%§ | 27.6% | 39.4% | 29.8% | — |
| Knowledge work | AA-Briefcase v11 (rubric score) | 66.1% | 61.5% | 61.2% | 52.0% | 61.8% |
| Knowledge work | AA-Briefcase v11 (Elo) | 1785 | 1669 | 1800 | 1569 | 1611 |
| Knowledge work | Remote Labor Index | 41.3%* | 17.9% | 21.3% | 20.8% | — |
| Multidisciplinary reasoning | Humanity’s Last Exam (with tools) | 74.2% | 65.6% | 67.7% | 57.2% | — |
| Visual chart recognition | Chartography (no tools) | 73.4% | 44.8% | 64.4% | 71.0% | 72.5% |

### Notes transcribed from the image

- The image footer says Fable 5.2, Fable 5.1, and Opus 5.5 scores shown are with safeguards on, unless otherwise noted.
- `*` Some results/labels identify Mythos 5.2 or Mythos 5.1 for the cybersecurity, protein-design, and Remote Labor Index entries; the precise labels are reproduced in the image cells and may refer to a different operating configuration from the column title.
- `†` Opus cybersecurity and protein-design cells say “without safeguards.”
- `‡` The GPT-6 Cyber cell is labeled “GPT-6 Cyber.”
- The image says CyScenarioBench lab scores are based on unique tasks.
- `§` The image says RoboDojo Sim shows the highest-available effort and was run internally.
- The image contains additional effort/rubric notes in individual cells (for example “Xhigh effort”, “Medium effort”, “rubric”, and model variants). The percentage/score is shown above; those notes are not a separate universal quality guarantee.

## How the skill uses this benchmark reference

The skill uses the comparison to make sure its workflow covers multiple kinds of work, not just code generation:

1. Agentic coding and software repair.
2. Business workflows and task completion.
3. Scientific and terminal-based research.
4. Security-aware reasoning and defensive review.
5. Scientific design workflows where safely and legitimately available.
6. Agentic search and evidence handling.
7. Computer-use reliability.
8. Robotics and simulation.
9. Long-horizon knowledge work.
10. Multidisciplinary reasoning and visual chart recognition.

For any actual evaluation, do not infer skill effectiveness from these numbers. Establish a baseline, define a representative task set, run the same tasks under controlled conditions, record model/tool versions and settings, score with the benchmark's own rubric, and report uncertainty and failures. A skill cannot change model weights or guarantee a higher ranking.
