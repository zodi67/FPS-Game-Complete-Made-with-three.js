#!/usr/bin/env python3
"""Dependency-free structural validator for the OmniForge Ultra skill bundle."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_FILES = [
    "SKILL.md",
    "README.md",
    "references/software-and-app-production.md",
    "references/game-and-3d-production.md",
    "references/secure-computer-operation.md",
    "references/research-math-and-data.md",
    "references/benchmark-inspired-scorecard.md",
    "templates/task-contract.md",
    "templates/bug-log.md",
    "templates/verification-report.md",
    "templates/release-checklist.md",
    "assets/benchmark-reference.png",
]


def main() -> int:
    errors: list[str] = []
    warnings: list[str] = []

    for rel in REQUIRED_FILES:
        if not (ROOT / rel).is_file():
            errors.append(f"Missing required file: {rel}")

    skill_path = ROOT / "SKILL.md"
    if skill_path.is_file():
        content = skill_path.read_text(encoding="utf-8")
        if not content.startswith("---\n"):
            errors.append("SKILL.md must begin with YAML frontmatter delimiter ---")
        else:
            parts = content.split("---", 2)
            if len(parts) < 3:
                errors.append("SKILL.md frontmatter is not closed")
            else:
                front = parts[1]
                name = re.search(r"(?m)^name:\s*([a-z0-9-]+)\s*$", front)
                desc = re.search(r"(?m)^description:\s*(.+)$", front)
                if not name:
                    errors.append("Frontmatter needs a lowercase hyphenated name")
                elif len(name.group(1)) > 64:
                    errors.append("Skill name exceeds 64 characters")
                if not desc:
                    errors.append("Frontmatter needs a description")
                elif len(desc.group(1).strip()) > 1024:
                    errors.append("Description exceeds 1024 characters")
        if not re.search(r"(?m)^#\s+", content):
            errors.append("SKILL.md needs a Markdown H1 heading")

        # Check local markdown links. Ignore anchors and external URLs.
        for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", content):
            target = target.strip().split("#", 1)[0]
            if not target or re.match(r"^[a-z]+://", target, re.I) or target.startswith("mailto:"):
                continue
            if not (skill_path.parent / target).exists():
                errors.append(f"Broken local link in SKILL.md: {target}")

    if not (ROOT / "scripts/validate_skill.py").exists():
        warnings.append("Validator script is missing")

    if errors:
        print("FAIL: package validation found issues")
        for item in errors:
            print(f"  - {item}")
        return 1

    print("PASS: required package files and basic SKILL.md structure are present")
    for item in warnings:
        print(f"WARNING: {item}")
    print("Note: this checks package structure only; it does not certify agent capability or project quality.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
