# Release / Handoff Checklist

## Product
- [ ] Scope and acceptance criteria reviewed
- [ ] No placeholder/stub in a must-have flow
- [ ] All visible controls tested
- [ ] Error, empty, loading, success, and recovery states checked
- [ ] Accessibility and responsive behavior reviewed where relevant

## Engineering
- [ ] Build/package succeeds
- [ ] Automated tests and summaries reviewed
- [ ] Logs and runtime console reviewed
- [ ] Data persistence and migration checked
- [ ] Dependencies and licenses reviewed
- [ ] Secrets and private data excluded

## Game / 3D (when relevant)
- [ ] Major assets inspected in engine
- [ ] Rig, weights, and animation transitions checked
- [ ] Collision/physics tested in real gameplay
- [ ] No critical clipping, z-fighting, floating, or broken navigation
- [ ] Target device performance profiled

## Security / operations
- [ ] Permissions and access scope minimized
- [ ] Risky actions approved
- [ ] Backup / rollback available
- [ ] No security control disabled
- [ ] External publication or sending explicitly approved

## Handoff
- [ ] Exact artifact paths provided
- [ ] Setup and usage instructions included
- [ ] Tests and evidence summarized
- [ ] Known issues and unverified areas disclosed
