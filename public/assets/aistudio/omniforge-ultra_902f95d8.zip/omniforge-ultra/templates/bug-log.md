# Defect / Repair Log

| ID | Severity | Component | Reproduction steps | Expected | Actual | Root cause | Fix | Regression checks | Status |
|---|---|---|---|---|---|---|---|---|---|
| BUG-001 | Critical / High / Medium / Low |  |  |  |  |  |  |  | Open |

## Severity guide
- **Critical:** data loss, security exposure, project cannot launch, core progression blocked, or severe crash.
- **High:** major feature broken, severe collision/physics issue, major visual obstruction, or broad compatibility break.
- **Medium:** partial feature failure, notable usability defect, or repeatable non-core bug.
- **Low:** cosmetic issue, minor alignment defect, or low-impact polish item.

Never mark an issue fixed until the reproduction steps or an equivalent regression test pass after the change.
