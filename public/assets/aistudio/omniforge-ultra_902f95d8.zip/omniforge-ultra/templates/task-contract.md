# Task Contract

## User outcome
- Requested deliverable:
- Intended users:
- Target platform/environment:

## Scope
- Must-have requirements:
- Quality targets translated into observable checks:
- Explicit exclusions:

## Constraints
- Tools/access actually available:
- Existing files/projects to preserve:
- Deadline/resource limits if stated:
- Security/privacy constraints:
- Licensing/attribution constraints:

## Assumptions
- Reversible assumptions selected:
- Decisions requiring user approval:

## Acceptance checklist
- [ ] Core behavior works
- [ ] All in-scope components are integrated
- [ ] Visual/UX review completed where relevant
- [ ] Error/failure paths tested where relevant
- [ ] Data/persistence verified where relevant
- [ ] Security/privacy review completed where relevant
- [ ] Target environment/build checked where possible
- [ ] Handoff instructions and known limitations included
