# Delivery and Verification Report

## 1. Delivered
- Artifact(s):
- Exact path(s):
- Version/build identifier:

## 2. Implemented
- Completed features/components:
- Integrated workflows:
- Important assumptions/defaults:

## 3. Verification evidence

| Check | Command / method | Environment | Result | Evidence / notes |
|---|---|---|---|---|
| Build / launch |  |  | PASS / FAIL / NOT RUN |  |
| Unit tests |  |  | PASS / FAIL / NOT RUN |  |
| Integration / E2E |  |  | PASS / FAIL / NOT RUN |  |
| UI / visual inspection |  |  | PASS / FAIL / NOT RUN |  |
| Physics / collision / animation |  |  | PASS / FAIL / NOT RUN |  |
| Security review |  |  | PASS / FAIL / NOT RUN |  |
| Performance |  |  | PASS / FAIL / NOT RUN |  |
| Device / browser compatibility |  |  | PASS / FAIL / NOT RUN |  |

## 4. Known limitations / not verified
- Not implemented:
- Not tested:
- External dependencies or access needed:
- Residual risks:

## 5. How to use
- Prerequisites:
- Install/open/run steps:
- Build/package steps:
- Troubleshooting:

## 6. Final status
- [ ] Complete against the agreed scope
- [ ] Partially complete — remaining items listed above
- [ ] Blocked — precise blocker and safest next action listed above

**Truthfulness rule:** Never mark PASS when a check did not run or when only source-code inspection was performed.
